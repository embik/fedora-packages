#ifndef _SWAYNAG_RENDER_H
#define _SWAYNAG_RENDER_H
#include "swaynag/swaynag.h"

void render_frame(struct swaynag *swaynag);

#endif
