#ifndef UTIL_ARRAY_H
#define UTIL_ARRAY_H

#include <stdint.h>
#include <stdlib.h>

size_t push_zeroes_to_end(uint32_t arr[], size_t n);

#endif
