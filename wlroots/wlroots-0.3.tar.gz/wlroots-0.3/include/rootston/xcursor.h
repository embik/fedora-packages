#ifndef ROOTSTON_XCURSOR_H
#define ROOTSTON_XCURSOR_H

#include <stdint.h>

#define ROOTS_XCURSOR_SIZE 24

#define ROOTS_XCURSOR_DEFAULT "left_ptr"
#define ROOTS_XCURSOR_MOVE "grabbing"
#define ROOTS_XCURSOR_ROTATE "grabbing"

#endif
