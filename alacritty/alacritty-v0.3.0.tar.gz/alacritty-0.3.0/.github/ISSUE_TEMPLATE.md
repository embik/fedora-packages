Which operating system does the issue occur on?

If on linux, are you using X11 or Wayland?

