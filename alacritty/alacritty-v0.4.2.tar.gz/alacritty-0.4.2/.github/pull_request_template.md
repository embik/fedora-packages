Please make sure to document all user-facing changes in the `CHANGELOG.md` file.

Draft PRs are always welcome, though unless otherwise requested PRs will not be reviewed until all required and optional CI steps are successful and they have left the draft stage.
